CREATE TABLE Servizi(
	 CodServizio INT NOT NULL
	 ,Servizio VARCHAR (15)
CONSTRAINT PK_Servizi_CodServizi PRIMARY KEY (CodServizio));

CREATE TABLE FascePrezzi (
	 CodServizio INT NOT NULL
	 ,NFascia VARCHAR (6) NOT NULL
	 ,RangeDimPuntoVendita VARCHAR (25)
	 ,Prezzo MONEY
CONSTRAINT PK_FascePrezzi_CodServizio_NFascia PRIMARY KEY (CodServizio,NFascia)
CONSTRAINT FK_FasciaPrezzi_Servizi_CodServizio FOREIGN KEY (CodServizio)
	 REFERENCES Servizi(CodServizio));

CREATE TABLE Clienti(
	 CodCliente VARCHAR (5) NOT NULL
	 ,RagioneSociale VARCHAR (30) NOT NULL
	 ,TipologiaCommercio VARCHAR (100)
CONSTRAINT PK_Clienti_CodCliente PRIMARY KEY (CodCliente));

CREATE TABLE Regioni (
	 CodRegione VARCHAR (3) NOT NULL
	 ,Regione VARCHAR (25)
CONSTRAINT PK_Regioni_CodRegione PRIMARY KEY (CodRegione));

CREATE TABLE PuntiVenditaClienti(
	 CodPuntoVendita INT NOT NULL
	 ,CodCliente VARCHAR (5) NOT NULL
	 ,NomePuntoVendita VARCHAR (30)
	 ,SedePuntoVendita VARCHAR (45)
	 ,CodRegione VARCHAR (3) NOT NULL
CONSTRAINT PK_PuntiVenditaClienti_CodPuntoVendita_CodCliente PRIMARY KEY (CodPuntoVendita, CodCliente),
CONSTRAINT FK_PuntiVenditaClienti_Clienti_CodCliente FOREIGN KEY (CodCliente)
	 REFERENCES Clienti ( CodCliente),
CONSTRAINT FK_PuntiVenditaClienti_Regioni_CodRegione FOREIGN KEY (CodRegione)
	 REFERENCES Regioni (CodRegione));

ALTER TABLE PuntiVenditaClienti
ALTER COLUMN SedePuntoVendita VARCHAR (80)

CREATE TABLE Distretti (
	 CodDistretto VARCHAR (4) NOT NULL
	 ,Regione VARCHAR (25)
	 ,CodRegione VARCHAR (3) NOT NULL
CONSTRAINT PK_Distretti_CodDistretto PRIMARY KEY (CodDistretto)
CONSTRAINT FK_Distretti_Regioni_CodRegione FOREIGN KEY (CodRegione)
	 REFERENCES Regioni (CodRegione));

CREATE TABLE Impiegati (
	 CodImpiegato VARCHAR (7) NOT NULL
	 ,Nome CHAR (25) NOT NULL
	 ,Cognome CHAR (25) NOT NULL
	 ,Mansione VARCHAR (20) NOT NULL
	 ,DataAssunzione DATE
	 ,CodDistretto VARCHAR (4) NOT NULL
CONSTRAINT PK_Impiegati_CodImpiegato PRIMARY KEY (CodImpiegato)
CONSTRAINT FK_Impiegati_Distretti_CodDistretto FOREIGN KEY (CodDistretto)
	 REFERENCES Distretti (CodDistretto));

ALTER TABLE Impiegati
ALTER COLUMN Mansione VARCHAR (40)

CREATE TABLE AccordiPrestazione(
	 CodAccordo VARCHAR (5) NOT NULL
	 ,CodCliente VARCHAR (5) NOT NULL
	 ,DataErogazioneServizio DATE
	 ,CodRegione VARCHAR (3) NOT NULL
CONSTRAINT PK_AcoordiPrestazione_CodAccordo PRIMARY KEY (CodAccordo)
CONSTRAINT FK_AccordiPrestazione_Regioni_CodRegione FOREIGN KEY (CodRegione)
	 REFERENCES Regioni (CodRegione),
CONSTRAINT FK_AccordiPrestazione_Clienti_CodCliente FOREIGN KEY (CodCliente)
	 REFERENCES Clienti (CodCliente));

CREATE TABLE Prestazioni (
	 CodAccordo VARCHAR (5) NOT NULL
	 ,LineaAccordo INT NOT NULL
	 ,CodServizio INT NOT NULL
	 ,NFascia VARCHAR (6) NOT NULL
	 ,Prezzo MONEY
	 ,ImportoTotale MONEY
CONSTRAINT PK_Prestazioni_CodAccordo_LineaAccordo PRIMARY KEY (CodAccordo, LineaAccordo),
CONSTRAINT FK_Prestazioni_AccordiPrestazione_CodAccordo FOREIGN KEY (CodAccordo)
	 REFERENCES AccordiPrestazione (CodAccordo),
CONSTRAINT FK_Prestazioni_Servizi_CodServizio FOREIGN KEY (CodServizio)
	 REFERENCES Servizi (CodServizio),
CONSTRAINT FK_Prestazioni_FascePrezzi_CodServizio_NFascia FOREIGN KEY (CodServizio,NFascia)
	 REFERENCES FascePrezzi (CodServizio,NFascia));

INSERT INTO Servizi
VALUES (01, 'Inventario'), (02, 'FacinStore');

INSERT INTO FascePrezzi ( CodServizio, NFascia, RangeDimPuntoVendita, Prezzo)
VALUES (01, 'F-1', '150 m2 - 300 me', 15000)
	  ,(01, 'F-2', '301 m2 - 600 m2', 30000)
	  ,(01, 'F-3', '601 m2 - 1200 m2', 50000)
	  ,(02, 'F-1', '150 m2 - 300 m2', 10000)
	  ,(02, 'F-2', '301 m2 - 600 m2', 15000)
	  ,(02, 'F-3', '601 m2 - 1200 m2', 20000);

INSERT INTO Regioni
VALUES ('R1', 'Abruzzo')
	  ,('R2','Basilicata')
	  ,('R3', 'Calabria')
	  ,('R4', 'Campania')
	  ,('R5', 'Emilia Romagna')
	  ,('R6', 'Friuli Venezi Giulia')
	  ,('R7', 'Lazio')
	  ,('R8', 'Liguria')
	  ,('R9', 'Lombardia')
	  ,('R10', 'Marche')
	  ,('R11', 'Molise')
	  ,('R12', 'Piemonte')
	  ,('R13', 'Puglia')
	  ,('R14', 'Sardegna')
	  ,('R15', 'Sicilia')
	  ,('R16', 'Toscana')
	  ,('R17', 'Trentino Alto Adige')
	  ,('R18', 'Umbria')
	  ,('R19', 'Valle d''Aosta')
	  ,('R20', 'Veneto');

INSERT INTO Distretti
VALUES ('DS01', 'Lazio','R7')
      ,('DS02', 'Abruzzo', 'R1')
	  ,('DS03', 'Lombardia', 'R9')
	
INSERT INTO Clienti (CodCliente, RagioneSociale, TipologiaCommercio)
VALUES ('C-001', 'Magazzini Gabrielli S.p.a.', 'Vendita al dettaglio generi alimentari e non alimentari.')
	  ,('C-002', 'LEROY MERLIN ITALIA S.R.L.', 'Vendita al dettaglio di articoli per il bricolage e il fai da te.')
	  ,('C-003', 'ACQUA & SAPONE S.R.L.', 'Vendita al dettaglio di prodotti per l''igiene della casa e pulizia della persona.')
	  ,('C-004', 'OBI Italia S.R.L.', 'Vendita al dettaglio di articoli per il bricolage e il fai da te.')
	  ,('C-005', 'Eurospin Lazio S.p.a.', 'Vendita al dettaglio generi alimentari e non alimentari.')
	  ,('C-006', 'Despar', 'Vendita al dettaglio generi alimentari e non alimentari.')
	  ,('C-007', 'Adidas Italy S.p.a.', 'Commercio al dettaglio di abbigliamento, accessori e articoli sportivi.')
	  ,('C-008', 'Thun Shop Sestu S.R.L.', 'Commercio al dettaglio di articoli da regalo e casalinghi .')
	  ,('C.009', 'CONAD SOC. COOP', 'Vendita al dettaglio generi alimentari e non alimentari.')
	  ,('C-010', 'Margherita CONAD S.p.a.', 'Vendita al dettaglio generi alimentari e non alimentari.')
	  ,('C-011', 'GAME7 ATHLETICS S.r.l.', 'Commercio al dettaglio di abbigliamento, accessori e articoli sportivi.')
	  ,('C-012', 'BRICOMAN Italia S.r.l.', 'Vendita al dettaglio di prodotti per la costruzione e manutenzione di edifici.')
	  ,('C-013', 'Primark Italy S.r.l.', 'Commercio al dettaglio di articoli di abbigliamento e accessori.')
	 ,('C-014', 'COOP ALLEANZA 3.0', 'Vendita al dettaglio generi alimentari e non alimentari.');

UPDATE Clienti
SET CodCliente = 'C-009', RagioneSociale = 'CONAD SOC. COOP', TipologiaCommercio = 'Vendita al dettaglio generi alimentari e non alimentari.'
WHERE CodCliente = 'C.009';

INSERT INTO PuntiVenditaClienti
VALUES (01, 'C-001', 'TIGRE', 'Via Marino da Caramanico, 59 Chieti (CH)', 'R1')
	  ,(02, 'C-001', 'OASI','Umberto I, 334 Montesilvano (PE)', 'R1')
	  ,(03, 'C-001', 'OASI', 'Via Nazionale Adriatica Nord, 1 Francavilla al Mare (CH)', 'R1')
	  ,(04, 'C-001', 'TIGRE', 'C.da Cannuccia, Raiano (AQ)', 'R1')
	  ,(05, 'C-001', 'OASI', 'Via Santo Spirito, 119 Lanciano (CH)', 'R1') 
	  ,(06, 'C-001', 'OASI', 'Via Nazionale, 621 Roseto Degli Abruzzi (TE)', 'R1')
	  ,(07, 'C-001', 'OASI', 'Via Galileo Galilei, 371 Giuglianova (TE)', 'R1')
	  ,(08, 'C-001', 'OASI', 'Via Solferino, 1 Porto San Giorgio (FM)', 'R10')
	  ,(09, 'C-001', 'OASI', 'Via Madonna delle Grazie, 53 Termoli (CB)', 'R11')
	  ,(10, 'C-001', 'OASI', 'Strada Statale, 80 Teramo (TE)', 'R1')
	  ,(01, 'C-002', 'Leroy Merlin', 'Via Emanuele Carnevale, 83 La Romanina (RM)', 'R7')
	  ,(02, 'C-002', 'Leroy Merlin', 'Via Bruno Pontecorvo, 35 Laurentina (RM)', 'R7')
	  ,(03, 'C-002', 'Leroy Merlin', 'Via Po, San Giovanni Teatino (CH)', 'R1')
	  ,(04, 'C-002', 'Leroy Merlin', 'Via Giacomo Peroni c/o Tecnopolo Tiburtino (RM)', 'R7')
	  ,(01, 'C-003', 'Acqua & Sapone', 'Via della Libert�, 120 Ortona (CH)', 'R1')
	  ,(02, 'C-003', 'Acqua & Sapone', 'Via Nino Sospiri sn Montesilvano (PE)', 'R1') 
	  ,(03, 'C-003', 'Acqua & Sapone', 'Circonvallazione Istoniense s.n. Vasto (CH)', 'R1')
	  ,(04, 'C-003', 'Acqua & Sapone', 'Via Nazionale, 163 Tortoreto Lido (TE)', 'R1')
	  ,(05, 'C-003', 'Acuqa & Sapone', 'Via Corsica, 19 Termoli (CB)', 'R11')
	  ,(06, 'C-003', 'Acqua & Sapone', 'Contrada Cerreto, 335/A Miglianico (CH)', 'R1')
	  ,(07, 'C-003', 'Acqua & Sapone', 'Via Trieste snc Giulianova Spiaggia (TE)', 'R1')
	  ,(08, 'C-003', 'Acqua & Sapone', 'Via Guido Rosato, 32 AB Lanciano (CH)', 'R1') 
	  ,(09, 'C-003', 'Acqua & Sapone', 'Via Olanda Termoli (CB)', 'R11') 
	  ,(10, 'C-003', 'Acqua & Sapone', 'Via G. Mazzarino, 8-10-12 Pescara (PE)', 'R1')
	  ,(11, 'C-003', 'Acqua & Sapone', 'Via Parigi, 1 Spoltore (PE)', 'R1') 
	  ,(12, 'C-003', 'Acqua & Sapone', 'Via Avezzano, 69 Scurcola Marsicana (AQ)', 'R1')
	  ,(13, 'C-003', 'Acqua & Sapone', ' Via Alcide De Gaspari, 90 San Salvo (CH)', 'R1')
	  ,(14, 'C-003', 'Acqua & Sapone', 'Via Nazionale, 518 Roseto Degli Abruzzi (TE)', 'R1')
	  ,(15, 'C-003', 'Acqua & Sapone', 'Via la Foresta, 17 Pratola Peligna (AQ)', 'R1') 
	  ,(01, 'C-004', 'OBI', 'Via Tiburtina Valeria Avezzano (AQ)', 'R1')
	  ,(02, 'C-004', 'OBI', 'Via Po San Giovanni Teatino (CH)', 'R1')
	  ,(01, 'C-005', 'Eurospin', 'Via del Circuito, 384 Pescara (PE)', 'R1')
	  ,(02, 'C-005', 'Eurospin', 'S.S.17 Ovest L''Aquila (AQ)', 'R1')
	  ,(01, 'C-006', 'Interspar', 'Via Tiburtina Valeri Pescacara (PE)', 'R1')
	  ,(02, 'C-006', 'Despar', 'Viale Pindaro, 14 Pescara (PE)', 'R1')
	  ,(03, 'C-006', 'Despar', 'Viale Bovio Pescara (PE9', 'R1')
	  ,(04, 'C-006', 'Interspar', 'Via Nazionale, 74 Cepagatti (PE)', 'R1')
	  ,(01, 'C-007', 'Adidas', 'Via Moscarolo Citt� Sant''Angelo (PE)', 'R1')
	  ,(02, 'C-007', 'Adidas', 'Via Tirino, 1 Chieti Scalo (CH)', 'R1')
	  ,(01, 'C-008', 'Thun', 'Via Tirino, 1 Chieti Scalo (CH)', 'R1')
	  ,(02, 'C-008', 'Thun', 'Via Giovanni Gronchi, 1 L''Aquila (AQ)', 'R1')
	  ,(03, 'C-008', 'Thun', 'Corso della Libert�. 67 Avezzano (AQ)', 'R1')
	  ,(01, 'C-009', 'Conad', 'Via Della Pacetta, 33 Milano (MI)', 'R9') 
	  ,(02, 'C-009', 'Conad', 'Viale Antonio Silvani, 3/7 Bologna (BO)', 'R5')
	  ,(01, 'C-010', 'Margherita', 'Via Orfeo, 38/E Bologna (BO)', 'R5')
	  ,(03, 'C-009', 'Conad City', 'Via Luigi Pirandello, 18 Bologna (BO)', 'R5')
	  ,(04, 'C-009', 'Conad', 'Contrad Riomoro, 10 Colonella (TE)', 'R1')
	  ,(05, 'C-009', 'Conad', 'Via Tirino, 1 Chieti Scalo (CH)', 'R1')
	  ,(06, 'C-009', 'Conad', 'Via Papa Giovanni XXIII Popoli (PE)', 'R1')
	  ,(07, 'C-009', 'Conad', 'Strada Provinciale Santa Liberata Ortona (CH)', 'R1')
	  ,(08, 'C-009', 'Conad', 'Via XX Settembre, 411/G Avezzano (AQ)', 'R1')
	  ,(02, 'C-010', 'Margherita', 'Via Pescara, 228 Chieti Scalo (CH)', 'R1')
	  ,(03, 'C-010', 'Margherita', 'Via Bartolomeo Cristofiri, 5B Firenze (FI)', 'R16')
	  ,(01, 'C-011', 'GAME7ATHLETICS', 'Via Tirino, 1 Chieti Scalo (CH9', 'R1')
	  ,(01, 'C-012', 'Tecnomat', 'Via Pontina Aprilia (LT)', 'R7')
	  ,(02, 'C-012', 'Tecnomat', 'Via Prenestina, 8 Roma (RM)', 'R7')
	  ,(01, 'C-013', 'Primark', 'Via Collatina Roma (13RM)', 'R7')
	  ,(02, 'C-013', 'Primark', 'Via Lurentina, 865 Roma (RM)', 'R7')
	  ,(03, 'C-013', 'Primark', 'Via Tirino, 1 Chieti Scalo (CH)', 'R1')
	  ,(01, 'C-014', 'IPERCOOP', 'Viale degli Aviatori, 126 Foggia (FG)', 'R13');



INSERT INTO Impiegati
VALUES ('B-01001', 'Luca', 'Di Domizio', 'Presidente', '01/02/2018','DS01')
	  ,('B-01002', 'Elisabetta', 'Ratto', 'Direttore Finanziario', '01/02/2018', 'DS01')
	  ,('B-01003', 'Elisabetta', 'Soccodato', 'Adetto gestione del personale', '01/02/2018', 'DS01')
	  ,('B-02001', 'Diego', 'Colagrande', 'Direttore Distretto', '01/02/2018', 'DS02')
	  ,('B-02002', 'Claudio', 'Bonomo', 'Supervisor', '01/02/2018', 'DS02')
	  ,('B-02003', 'Federica', 'Santini', 'Supervisor', '2018/04/28', 'DS02')
	  ,('B-02004', 'Anthony', 'Padula', 'Supervisor', '2018/04/28', 'DS02')
	  ,('B-02005', 'Giulia', 'Governatori', 'TeamLeader', '2018/05/01', 'DS02')
	  ,('B-02006', 'Francesco', 'Marino', 'TeamLeader', '2018/05/01', 'DS02')
	  ,('B-02007', 'Isabella', 'Giannini', 'TeamLeader', '2018/07/01', 'DS02')
	  ,('B-02008', 'Simona', 'Di Giacomo', 'Inventarista', '2019/05/29', 'DS02')
	  ,('B-02009', 'Riccardo', 'Silvestri', 'Inventarista', '2019/05/29', 'DS02')
	  ,('B-02010', 'Luana', 'Giannascoli', 'Inventarista', '2019/12/15', 'DS02')
	  ,('B-02011', 'Daniele', 'Domizio', 'Inventarista', '2019/12/15', 'DS02')
	  ,('B-02012', 'Martina', 'Petti', 'Inventarista', '2020/01/15', 'DS02')
	  ,('B-02013', 'Alessia', 'Marconi', 'Inventarista', '2020/01/15', 'DS02')
	  ,('B-02014', 'Vittorio', 'Bonomini', 'Inventarista', '2020/05/28', 'DS02')
	  ,('B-02015', 'Dario', 'Brilli', 'Inventarista', '2020/05/28', 'DS02')
	  ,('B-02016', 'Monica', 'Flatti', 'Inventarista', '2020/09/15', 'DS02')
	  ,('B-02017', 'Federica', 'Rospi', 'Inventarista', '2021/01/15', 'DS02')
	  ,('B-02018', 'Giulia', 'Gori', 'Inventarista','2021/01/15', 'DS02')
	  ,('B-01004', 'Giorgia', 'Paddi', 'Direttore Distretto', '2018/04/28', 'DS01')
	  ,('B-01005', 'Gianni', 'Vitti', 'Supervisor', '2018/04/28', 'DS01')
	  ,('B-01006', 'Francesco', 'Sassi', 'Supervisor', '2018/04/28', 'DS01')
	  ,('B-01007', 'Ivan', 'Gianni', 'Supervisor', '2018/05/01', 'DS01')
	  ,('B-01008', 'Stefania', 'Di Santo', 'TeamLeader', '2018/05/01', 'DS01')
	  ,('B-01009', 'Riccardo', 'D''Amico', 'TeamLeader', '2018/05/01', 'DS01')
	  ,('B-01010', 'Lisa', 'Facchini', 'TeamLeader', '2018/07/01', 'DS01')
	  ,('B-01011', 'Davide', 'Fantozzi', 'TeamLeader', '2018/07/01', 'DS01')
	  ,('B-01012', 'Martina', 'Salvati', 'TeamLeader', '2018/07/15', 'DS01')
	  ,('B-01013', 'Alessia', 'Calzoni', 'Inventarista', '2019/09/01', 'DS01')
	  ,('B-01014', 'Alessia', 'Ciammaichella', 'Inventarista', '2019/09/01', 'DS01')
	  ,('B-01015', 'Giacomo', 'Salvatore', 'Inventarista', '2019/09/01', 'DS01')
	  ,('B-01016', 'Jessica', 'Savini', 'Inventarista', '2019/12/15', 'DS01')
	  ,('B-01017', 'Marco', 'Pitti', 'Inventarista', '2019/12/15', 'DS01')
	  ,('B-01018', 'Michele', 'Bravi', 'Inventarista','2019/12/15', 'DS01')
	  ,('B-01019', 'Alessandro', 'Sabotini', 'Inventarista', '2019/12/15', 'DS01')
	  ,('B-01020', 'Vittorio', 'Di Menna', 'Inventarista', '2020/12/15', 'DS01')
	  ,('B-01021', 'MariaClaudia', 'Zillo', 'Inventarista', '2021/01/15', 'DS01')
	  ,('B-01022', 'Monica', 'Cicchini', 'Inventarista', '2021/01/15', 'DS01')
	  ,('B-01023', 'Nina', 'Travisi', 'Inventarista', '2021/05/28', 'DS01') 
	  ,('B-01024', 'Mariano', 'Vorgi', 'Inventarista', '2021/05/28', 'DS01')
	  ,('B-03001', 'Giovanni', 'Tucci', 'Direttore Distretto', '2018/04/28', 'DS03')
	  ,('B-03002', 'Dania', 'Bendi', 'Supervisor', '2018/04/28', 'DS03')
	  ,('B-03003', 'Filoppo', 'Matricardi', 'Supervisor', '2018/04/28', 'DS03')
	  ,('B-03004', 'Ida', 'Cozzi', 'Supervisor', '2018/05/01', 'DS03')
	  ,('B-03005', 'Lorenzo', 'Di Sanctos', 'TeamLeader', '2018/05/01', 'DS03')
	  ,('B-03006', 'Lorenza', 'Ricci', 'TeamLeader', '2018/05/01', 'DS03')
	  ,('B-03007', 'Luisa', 'Fratti', 'TeamLeader', '2018/05/01', 'DS03')
	  ,('B-03008', 'Chiara', 'Bevilacqua', 'TeamLeader', '2018/07/15', 'DS03')
	  ,('B-03009', 'Mario', 'Salvati', 'TeamLeader', '2018/07/15', 'DS03')
	  ,('B-03010', 'Alessio', 'Zuccarini', 'Inventarista', '2019/09/01', 'DS03')
	  ,('B-03011', 'Victor', 'Zaldi', 'Inventarista', '2019/09/01', 'DS03')
	  ,('B-03012', 'Fabiana', 'De Vito', 'Inventarista', '2019/09/01', 'DS03')
	  ,('B-03013', 'Livio', 'Fantini', 'Inventarista','2019/12/15', 'DS03')
	  ,('B-03014', 'Marco', 'Pardei', 'Inventarista', '2020/01/15', 'DS03')
	  ,('B-03015', 'Michele', 'Utti', 'Inventarista', '2020/01/15', 'DS03')
	  ,('B-03016', 'Nicola', 'Taralli', 'Inventarista', '2020/12/01', 'DS03')
	  ,('B-03017', 'Maria', 'Lalli', 'Inventarista', '2021/01/15', 'DS03');

INSERT INTO AccordiPrestazione
VALUES ('A-001', 'C-001', '2018/12/26', 'R1')
	  ,('A-002', 'C-001', '2019/01/02', 'R1')
	  ,('A-003', 'C-002', '2019/01/13', 'R7')
	  ,('A-004', 'C-002', '2019/01/20', 'R1')
	  ,('A-005', 'C-004', '2019/06/10', 'R1')
	  ,('A-006', 'C-005', '2019/06/16', 'R1')
	  ,('A-007', 'C-007', '2019/07/15', 'R1')
	  ,('A-008', 'C-003', '2019/10/12', 'R1')
	  ,('A-009', 'C-003', '2019/11/05', 'R1')
	  ,('A-010', 'C-003', '2019/11/14', 'R11')
	  ,('A-011', 'C-006', '2019/11/20', 'R1')
	  ,('A-012', 'C-008', '2019/11/26', 'R1')
	  ,('A-013', 'C-009', '2019/11/27', 'R9')
	  ,('A-014', 'C-009', '2019/11/27', 'R5')
	  ,('A-015', 'C-009', '2019/11/27', 'R1')
	  ,('A-016', 'C-010', '2019/11/30', 'R5')
	  ,('A-017', 'C-010', '2019/11/30', 'R16')
	  ,('A-018', 'C-010', '2019/11/30', 'R1')
	  ,('A-019', 'C-011', '2019/12/05', 'R1')
	  ,('A-020', 'C-012', '2019/12/07', 'R7')
	  ,('A-021', 'C-014', '2019/12/13', 'R13')
	  ,('A-022', 'C-001', '2019/12/26', 'R1')
	  ,('A-023', 'C-001', '2020/01/02', 'R1')
	  ,('A-024', 'C-002', '2020/01/13', 'R7')
	  ,('A-025', 'C-002', '2020/01/20', 'R1')
	  ,('A-026', 'C-004', '2020/06/10', 'R1')
	  ,('A-027', 'C-005', '2020/06/16', 'R1')
	  ,('A-028', 'C-007', '2020/07/15', 'R1')
	  ,('A-029', 'C-003', '2020/10/12', 'R1')
	  ,('A-030', 'C-003', '2020/11/05', 'R1')
	  ,('A-031', 'C-003', '2020/11/14', 'R11')
	  ,('A-032', 'C-006', '2020/11/20', 'R1')
	  ,('A-033', 'C-008', '2020/11/26', 'R1')
	  ,('A-034', 'C-009', '2020/11/27', 'R9')
	  ,('A-035', 'C-009', '2020/11/27', 'R5')
	  ,('A-036', 'C-009', '2020/11/27', 'R1')
	  ,('A-037', 'C-010', '2020/11/30', 'R5')
	  ,('A-038', 'C-010', '2020/11/30', 'R16')
	  ,('A-039', 'C-010', '2020/11/30', 'R1')
	  ,('A-040', 'C-011', '2020/12/05', 'R1')
	  ,('A-041', 'C-012', '2020/12/07', 'R7')
	  ,('A-042', 'C-013', '2020/12/26', 'R7')
	  ,('A-043', 'C-013', '2020/12/29', 'R1')
	  ,('A-044', 'C-001', '2021/01/02', 'R1')
	  ,('A-045', 'C-001', '2021/01/10', 'R1')
	  ,('A-046', 'C-002', '2021/01/13', 'R7')
	  ,('A-047', 'C-002', '2021/01/20', 'R1')
	  ,('A-048', 'C-004', '2021/06/10', 'R1')
	  ,('A-049', 'C-005', '2021/06/16', 'R1')
	  ,('A-050', 'C-007', '2021/07/15', 'R1')
	  ,('A-051', 'C-003', '2021/10/12', 'R1')
	  ,('A-052', 'C-003', '2021/11/05', 'R1')
	  ,('A-053', 'C-003', '2021/11/14', 'R11')
	  ,('A-054', 'C-006', '2021/11/20', 'R1')
	  ,('A-055', 'C-008', '2021/11/26', 'R1')
	  ,('A-056', 'C-009', '2021/11/27', 'R9')
	  ,('A-057', 'C-009', '2021/11/27', 'R5')
	  ,('A-058', 'C-009', '2021/11/27', 'R1')
	  ,('A-059', 'C-010', '2021/11/30', 'R5')
	  ,('A-060', 'C-010', '2021/11/30', 'R16')
	  ,('A-061', 'C-010', '2021/11/30', 'R1')
	  ,('A-062', 'C-011', '2021/12/05', 'R1')
	  ,('A-063', 'C-012', '2021/12/07', 'R7')
	  ,('A-064', 'C-013', '2021/12/26', 'R7')
	  ,('A-065', 'C-013', '2021/12/29', 'R1')
	  ,('A-066', 'C-001', '2022/01/02', 'R1')
	  ,('A-067', 'C-001', '2022/01/10', 'R1')
	  ,('A-068', 'C-002', '2022/01/13', 'R7')
	  ,('A-069', 'C-002', '2022/01/20', 'R1')
	  ,('A-070', 'C-004', '2022/06/10', 'R1')
	  ,('A-071', 'C-005', '2022/06/16', 'R1')
	  ,('A-072', 'C-007', '2022/07/15', 'R1')
	  ,('A-073', 'C-003', '2022/10/12', 'R1')
	  ,('A-074', 'C-003', '2022/11/05', 'R1')
	  ,('A-075', 'C-003', '2022/11/14', 'R11')
	  ,('A-076', 'C-006', '2022/11/20', 'R1')
	  ,('A-077', 'C-008', '2022/11/26', 'R1')
	  ,('A-078', 'C-009', '2022/11/27', 'R9')
	  ,('A-079', 'C-009', '2022/11/27', 'R5')
	  ,('A-080', 'C-009', '2022/11/27', 'R1')
	  ,('A-081', 'C-010', '2022/11/30', 'R5')
	  ,('A-082', 'C-010', '2022/11/30', 'R16')
	  ,('A-083', 'C-010', '2022/11/30', 'R1')
	  ,('A-084', 'C-011', '2022/12/05', 'R1')
	  ,('A-085', 'C-012', '2022/12/07', 'R7')
	  ,('A-086', 'C-013', '2022/12/26', 'R7')
	  ,('A-087', 'C-013', '2022/12/29', 'R1')
	  ,('A-088', 'C-001', '2023/01/02', 'R1')
	  ,('A-089', 'C-001', '2023/01/10', 'R1')
	  ,('A-090', 'C-002', '2023/01/13', 'R7')
	  ,('A-091', 'C-002', '2023/01/20', 'R1')
	  ,('A-092', 'C-004', '2023/06/10', 'R1')
	  ,('A-093', 'C-005', '2023/06/16', 'R1');

INSERT INTO Prestazioni
VALUES ('A-001', '1', '01', 'F-2', '30000', '30000')
	  ,('A-001', '2', '01', 'F-2', '30000', '30000')
	  ,('A-001', '3', '01', 'F-3', '50000', '50000')
	  ,('A-002', '1', '01', 'F-2', '30000', '30000')
	  ,('A-002', '2', '01', 'F-1', '15000', '15000')
	  ,('A-002', '3', '01', 'F-2', '30000', '30000')
	  ,('A-002', '4', '01', 'F-3', '50000', '50000')
	  ,('A-002', '5', '01', 'F-3', '50000', '50000')
	  ,('A-003', '1', '01', 'F-3', '50000', '50000')
	  ,('A-003', '2', '01', 'F-3', '50000', '50000')
	  ,('A-003', '3', '01', 'F-3', '50000', '50000')
	  ,('A-004', '1', '01', 'F-2', '30000', '30000')
	  ,('A-005', '1', '01', 'F-3', '50000', '50000')
	  ,('A-005', '2', '01', 'F-3', '50000', '50000')
	  ,('A-006', '1', '01', 'F-2', '30000', '30000')
	  ,('A-006', '2', '01', 'F-1', '15000', '15000')
	  ,('A-007', '1', '01', 'F-1', '15000', '15000')
	  ,('A-007', '2', '01', 'F-1', '15000', '15000')
	  ,('A-008', '1', '01', 'F-2', '30000', '30000')
	  ,('A-008', '2', '01', 'F-2', '30000', '30000')
	  ,('A-009', '1', '01', 'F-2', '30000', '30000')
	  ,('A-009', '2', '01', 'F-2', '30000', '30000')
	  ,('A-009', '3', '01', 'F-1', '15000', '15000')
	  ,('A-009', '4', '01', 'F-2', '30000', '30000')
	  ,('A-009', '5', '01', 'F-2', '30000', '30000')
	  ,('A-009', '6', '01', 'F-1', '15000', '15000')
	  ,('A-009', '7', '01', 'F-2', '30000', '30000')
	  ,('A-010', '1', '01', 'F-2', '30000', '30000')
	  ,('A-010', '2', '01', 'F-2', '30000', '30000')
	  ,('A-010', '3', '01', 'F-2', '30000', '30000')
	  ,('A-010', '4', '01', 'F-1', '15000', '15000')
	  ,('A-010', '5', '01', 'F-2', '30000', '30000')
	  ,('A-010', '6', '01', 'F-2', '30000', '30000')
	  ,('A-011', '1', '01', 'F-3', '50000', '50000')
	  ,('A-011', '2', '01', 'F-2', '30000', '30000')
	  ,('A-011', '3', '01', 'F-2', '30000', '30000')
	  ,('A-011', '4', '01', 'F-3', '50000', '50000')
	  ,('A-012', '1', '01', 'F-1', '15000', '15000')
	  ,('A-012', '2', '01', 'F-1', '15000', '15000')
	  ,('A-012', '3', '01', 'F-1', '15000', '15000')
	  ,('A-013', '1', '01', 'F-2', '30000', '30000')
	  ,('A-014', '1', '01', 'F-2', '30000', '30000')
	  ,('A-014', '2', '01', 'F-1', '15000', '15000')
	  ,('A-015', '1', '01', 'F-1', '15000', '15000')
	  ,('A-015', '2', '01', 'F-2', '30000', '30000')
	  ,('A-015', '3', '01', 'F-3', '50000', '50000')
	  ,('A-015', '4', '01', 'F-3', '50000', '50000')
	  ,('A-016', '1', '01', 'F-2', '30000', '30000')
	  ,('A-017', '1', '01', 'F-1', '15000', '15000')
	  ,('A-018', '1', '01', 'F-1', '15000', '15000')
	  ,('A-019', '1', '01', 'F-1', '15000', '15000')
	  ,('A-020', '1', '01', 'F-3', '50000', '50000')
	  ,('A-020', '2', '01', 'F-3', '50000', '50000')
	  ,('A-021', '1', '01', 'F-3', '50000', '50000')
	  ,('A-022', '1', '01', 'F-2', '30000', '30000')
	  ,('A-022', '2', '01', 'F-2', '30000', '30000')
	  ,('A-022', '3', '01', 'F-3', '50000', '50000')
	  ,('A-023', '1', '01', 'F-2', '30000', '30000')
	  ,('A-023', '2', '01', 'F-1', '15000', '15000')
	  ,('A-023', '3', '01', 'F-2', '30000', '30000')
	  ,('A-023', '4', '01', 'F-3', '50000', '50000')
	  ,('A-023', '5', '01', 'F-3', '50000', '50000')
	  ,('A-024', '1', '01', 'F-3', '50000', '50000')
	  ,('A-024', '2', '01', 'F-3', '50000', '50000')
	  ,('A-024', '3', '01', 'F-3', '50000', '50000')
	  ,('A-025', '1', '01', 'F-2', '30000', '30000')
	  ,('A-026', '1', '01', 'F-3', '50000', '50000')
	  ,('A-026', '2', '01', 'F-3', '50000', '50000')
	  ,('A-027', '1', '01', 'F-2', '30000', '30000')
	  ,('A-027', '2', '01', 'F-1', '15000', '15000')
	  ,('A-028', '1', '01', 'F-1', '15000', '15000')
	  ,('A-028', '2', '01', 'F-1', '15000', '15000')
	  ,('A-029', '1', '01', 'F-2', '30000', '30000')
	  ,('A-029', '2', '01', 'F-2', '30000', '30000')
	  ,('A-030', '1', '01', 'F-2', '30000', '30000')
	  ,('A-030', '2', '01', 'F-2', '30000', '30000')
	  ,('A-030', '3', '01', 'F-1', '15000', '15000')
	  ,('A-030', '4', '01', 'F-2', '30000', '30000')
	  ,('A-030', '5', '01', 'F-2', '30000', '30000')
	  ,('A-030', '6', '01', 'F-1', '15000', '15000')
	  ,('A-030', '7', '01', 'F-2', '30000', '30000')
	  ,('A-031', '1', '01', 'F-2', '30000', '30000')
	  ,('A-031', '2', '01', 'F-2', '30000', '30000')
	  ,('A-031', '3', '01', 'F-2', '30000', '30000')
	  ,('A-031', '4', '01', 'F-1', '15000', '15000')
	  ,('A-031', '5', '01', 'F-2', '30000', '30000')
	  ,('A-031', '6', '01', 'F-2', '30000', '30000')
	  ,('A-032', '1', '01', 'F-3', '50000', '50000')
	  ,('A-032', '2', '01', 'F-2', '30000', '30000')
	  ,('A-032', '3', '01', 'F-2', '30000', '30000')
	  ,('A-032', '4', '01', 'F-3', '50000', '50000')
	  ,('A-033', '1', '01', 'F-1', '15000', '15000')
	  ,('A-033', '2', '01', 'F-1', '15000', '15000')
	  ,('A-033', '3', '01', 'F-1', '15000', '15000')
	  ,('A-034', '1', '01', 'F-2', '30000', '30000')
	  ,('A-035', '1', '01', 'F-2', '30000', '30000')
	  ,('A-035', '2', '01', 'F-1', '15000', '15000')
	  ,('A-036', '1', '01', 'F-1', '15000', '15000')
	  ,('A-036', '2', '01', 'F-2', '30000', '30000')
	  ,('A-036', '3', '01', 'F-3', '50000', '50000')
	  ,('A-036', '4', '01', 'F-3', '50000', '50000')
	  ,('A-037', '1', '01', 'F-2', '30000', '30000')
	  ,('A-038', '1', '01', 'F-1', '15000', '15000')
	  ,('A-039', '1', '01', 'F-1', '15000', '15000')
	  ,('A-040', '1', '01', 'F-1', '15000', '15000')
	  ,('A-041', '1', '01', 'F-3', '50000', '50000')
	  ,('A-041', '2', '01', 'F-3', '50000', '50000')
	  ,('A-042', '1', '01', 'F-3', '50000', '50000')
	  ,('A-042', '2', '01', 'F-3', '50000', '50000')
	  ,('A-043', '1', '01', 'F-3', '50000', '50000')
	  ,('A-044', '1', '01', 'F-2', '30000', '30000')
	  ,('A-044', '2', '01', 'F-2', '30000', '30000')
	  ,('A-044', '3', '01', 'F-3', '50000', '50000')
	  ,('A-045', '1', '01', 'F-2', '30000', '30000')
	  ,('A-045', '2', '01', 'F-1', '15000', '15000')
	  ,('A-045', '3', '01', 'F-2', '30000', '30000')
	  ,('A-045', '4', '01', 'F-3', '50000', '50000')
	  ,('A-045', '5', '01', 'F-3', '50000', '50000')
	  ,('A-046', '1', '01', 'F-3', '50000', '50000')
	  ,('A-046', '2', '01', 'F-3', '50000', '50000')
	  ,('A-046', '3', '01', 'F-3', '50000', '50000')
	  ,('A-047', '1', '01', 'F-2', '30000', '30000')
	  ,('A-048', '1', '01', 'F-3', '50000', '50000')
	  ,('A-048', '2', '01', 'F-3', '50000', '50000')
	  ,('A-049', '1', '01', 'F-2', '30000', '30000')
	  ,('A-049', '2', '01', 'F-1', '15000', '15000')
	  ,('A-050', '1', '01', 'F-1', '15000', '15000')
	  ,('A-050', '2', '01', 'F-1', '15000', '15000')
	  ,('A-051', '1', '01', 'F-2', '30000', '30000')
	  ,('A-051', '2', '01', 'F-2', '30000', '30000')
	  ,('A-052', '1', '01', 'F-2', '30000', '30000')
	  ,('A-052', '2', '01', 'F-2', '30000', '30000')
	  ,('A-052', '3', '01', 'F-1', '15000', '15000')
	  ,('A-052', '4', '01', 'F-2', '30000', '30000')
	  ,('A-052', '5', '01', 'F-2', '30000', '30000')
	  ,('A-052', '6', '01', 'F-1', '15000', '15000')
	  ,('A-052', '7', '01', 'F-2', '30000', '30000')
	  ,('A-053', '1', '01', 'F-2', '30000', '30000')
	  ,('A-053', '2', '01', 'F-2', '30000', '30000')
	  ,('A-053', '3', '01', 'F-2', '30000', '30000')
	  ,('A-053', '4', '01', 'F-1', '15000', '15000')
	  ,('A-053', '5', '01', 'F-2', '30000', '30000')
	  ,('A-053', '6', '01', 'F-2', '30000', '30000')
	  ,('A-054', '1', '01', 'F-3', '50000', '50000')
	  ,('A-054', '2', '01', 'F-2', '30000', '30000')
	  ,('A-054', '3', '01', 'F-2', '30000', '30000')
	  ,('A-054', '4', '01', 'F-3', '50000', '50000')
	  ,('A-055', '1', '01', 'F-1', '15000', '15000')
	  ,('A-055', '2', '01', 'F-1', '15000', '15000')
	  ,('A-055', '3', '01', 'F-1', '15000', '15000')
	  ,('A-056', '1', '01', 'F-2', '30000', '30000')
	  ,('A-057', '1', '01', 'F-2', '30000', '30000')
	  ,('A-057', '2', '01', 'F-1', '15000', '15000')
	  ,('A-058', '1', '01', 'F-1', '15000', '15000')
	  ,('A-058', '2', '01', 'F-2', '30000', '30000')
	  ,('A-058', '3', '01', 'F-3', '50000', '50000')
	  ,('A-058', '4', '01', 'F-3', '50000', '50000')
	  ,('A-059', '1', '01', 'F-2', '30000', '30000')
	  ,('A-060', '1', '01', 'F-1', '15000', '15000')
	  ,('A-061', '1', '01', 'F-1', '15000', '15000')
	  ,('A-062', '1', '01', 'F-1', '15000', '15000')
	  ,('A-063', '1', '01', 'F-3', '50000', '50000')
	  ,('A-063', '2', '01', 'F-3', '50000', '50000')
	  ,('A-064', '1', '01', 'F-3', '50000', '50000')
	  ,('A-064', '2', '01', 'F-3', '50000', '50000')
	  ,('A-065', '1', '01', 'F-3', '50000', '50000')
	  ,('A-066', '1', '01', 'F-2', '30000', '30000')
	  ,('A-066', '2', '01', 'F-2', '30000', '30000')
	  ,('A-066', '3', '01', 'F-3', '50000', '50000')
	  ,('A-067', '1', '01', 'F-2', '30000', '30000')
	  ,('A-067', '2', '01', 'F-1', '15000', '15000')
	  ,('A-067', '3', '01', 'F-2', '30000', '30000')
	  ,('A-067', '4', '01', 'F-3', '50000', '50000')
	  ,('A-067', '5', '01', 'F-3', '50000', '50000')
	  ,('A-068', '1', '01', 'F-3', '50000', '50000')
	  ,('A-068', '2', '01', 'F-3', '50000', '50000')
	  ,('A-068', '3', '01', 'F-3', '50000', '50000')
	  ,('A-069', '1', '01', 'F-2', '30000', '30000')
	  ,('A-070', '1', '01', 'F-3', '50000', '50000')
	  ,('A-070', '2', '01', 'F-3', '50000', '50000')
	  ,('A-071', '1', '01', 'F-2', '30000', '30000')
	  ,('A-071', '2', '01', 'F-1', '15000', '15000')
	  ,('A-072', '1', '01', 'F-1', '15000', '15000')
	  ,('A-072', '2', '01', 'F-1', '15000', '15000')
	  ,('A-073', '1', '01', 'F-2', '30000', '30000')
	  ,('A-073', '2', '01', 'F-2', '30000', '30000')
	  ,('A-074', '1', '01', 'F-2', '30000', '30000')
	  ,('A-074', '2', '01', 'F-2', '30000', '30000')
	  ,('A-074', '3', '01', 'F-1', '15000', '15000')
	  ,('A-074', '4', '01', 'F-2', '30000', '30000')
	  ,('A-074', '5', '01', 'F-2', '30000', '30000')
	  ,('A-074', '6', '01', 'F-1', '15000', '15000')
	  ,('A-074', '7', '01', 'F-2', '30000', '30000')
	  ,('A-075', '1', '01', 'F-2', '30000', '30000')
	  ,('A-075', '2', '01', 'F-2', '30000', '30000')
	  ,('A-075', '3', '01', 'F-2', '30000', '30000')
	  ,('A-075', '4', '01', 'F-1', '15000', '15000')
	  ,('A-075', '5', '01', 'F-2', '30000', '30000')
	  ,('A-075', '6', '01', 'F-2', '30000', '30000')
	  ,('A-076', '1', '01', 'F-3', '50000', '50000')
	  ,('A-076', '2', '01', 'F-2', '30000', '30000')
	  ,('A-076', '3', '01', 'F-2', '30000', '30000')
	  ,('A-076', '4', '01', 'F-3', '50000', '50000')
	  ,('A-077', '1', '01', 'F-1', '15000', '15000')
	  ,('A-077', '2', '01', 'F-1', '15000', '15000')
	  ,('A-077', '3', '01', 'F-1', '15000', '15000')
	  ,('A-078', '1', '01', 'F-2', '30000', '30000')
	  ,('A-079', '1', '01', 'F-2', '30000', '30000')
	  ,('A-079', '2', '01', 'F-1', '15000', '15000')
	  ,('A-080', '1', '01', 'F-1', '15000', '15000')
	  ,('A-080', '2', '01', 'F-2', '30000', '30000')
	  ,('A-080', '3', '01', 'F-3', '50000', '50000')
	  ,('A-080', '4', '01', 'F-3', '50000', '50000')
	  ,('A-081', '1', '01', 'F-2', '30000', '30000')
	  ,('A-082', '1', '01', 'F-1', '15000', '15000')
	  ,('A-083', '1', '01', 'F-1', '15000', '15000')
	  ,('A-084', '1', '01', 'F-1', '15000', '15000')
	  ,('A-085', '1', '01', 'F-3', '50000', '50000')
	  ,('A-085', '2', '01', 'F-3', '50000', '50000')
	  ,('A-086', '1', '01', 'F-3', '50000', '50000')
	  ,('A-086', '2', '01', 'F-3', '50000', '50000')
	  ,('A-087', '1', '01', 'F-3', '50000', '50000')
	  ,('A-088', '1', '01', 'F-2', '30000', '30000')
	  ,('A-088', '2', '01', 'F-2', '30000', '30000')
	  ,('A-088', '3', '01', 'F-3', '50000', '50000')
	  ,('A-089', '1', '01', 'F-2', '30000', '30000')
	  ,('A-089', '2', '01', 'F-1', '15000', '15000')
	  ,('A-089', '3', '01', 'F-2', '30000', '30000')
	  ,('A-089', '4', '01', 'F-3', '50000', '50000')
	  ,('A-089', '5', '01', 'F-3', '50000', '50000')
	  ,('A-090', '1', '01', 'F-3', '50000', '50000')
	  ,('A-090', '2', '01', 'F-3', '50000', '50000')
	  ,('A-090', '3', '01', 'F-3', '50000', '50000')
	  ,('A-091', '1', '01', 'F-2', '30000', '30000')
	  ,('A-092', '1', '01', 'F-3', '50000', '50000')
	  ,('A-092', '2', '01', 'F-3', '50000', '50000')
	  ,('A-093', '1', '01', 'F-2', '30000', '30000')
	  ,('A-093', '2', '01', 'F-1', '15000', '15000');



--1.Elenco delle Regioni in cui vi � un Distretto di CONTA

SELECT r.Regione
	  ,d.CodDistretto Distretto
FROM Regioni r
INNER JOIN Distretti d
ON r.CodRegione = d.CodRegione

--2.Elenco di tutti gli impiegati del Distretto della regione Lazio

SELECT CONCAT (i.Nome,' ',i.Cognome) Impiegato
	  ,d.CodDistretto                Distretto
	  ,r.Regione                     Regione
FROM Impiegati i
INNER JOIN Distretti d
ON i.CodDistretto = d.CodDistretto
INNER JOIN Regioni r
ON d.CodRegione = r.CodRegione
WHERE r.Regione = 'Lazio'

--3.Conteggio degli impiegati per ogni distretto

SELECT d.CodDistretto Distretto
	  ,COUNT (i.CodImpiegato) NumeroImpiegati
FROM Distretti d
INNER JOIN Impiegati i
ON d.CodDistretto = i.CodDistretto
GROUP BY d.CodDistretto

--4.Esporre il totale degli Inventari svolti in Emilia Romagna, per anno, e l'importo totale degli inventari.

SELECT YEAR (ap.DataErogazioneServizio) Anno
	  ,COUNT (ap.CodAccordo)            PuntiVenditaInventariati
	  ,SUM(p.ImportoTotale)             ImportoTotale
	  ,r.Regione
FROM Prestazioni p
INNER JOIN AccordiPrestazione ap
ON p.CodAccordo = ap.CodAccordo
INNER JOIN Regioni r
ON ap.CodRegione = r.CodRegione
GROUP BY YEAR (ap.DataErogazioneServizio),r.Regione 
HAVING r.Regione = 'Emilia Romagna'
ORDER BY YEAR (ap.DataErogazioneServizio)

--5.Elenco degli inventari svolti nel 2023, con esposizione del Nome del punto vendita.

SELECT pv.NomePuntoVendita
	  , pv.SedePuntoVendita
	  ,YEAR ( ap.DataErogazioneServizio) Anno
FROM AccordiPrestazione ap
INNER JOIN PuntiVenditaClienti pv
ON ap.CodCliente = pv.CodCliente
GROUP BY YEAR ( ap.DataErogazioneServizio), pv.NomePuntoVendita, pv.SedePuntoVendita
HAVING YEAR ( ap.DataErogazioneServizio) = '2023'

--6.Elenco clienti con punti vendita nella regione Abruzzo

SELECT c.RagioneSociale Cliente
	  ,COUNT (pv.CodPuntoVendita) PuntiVendita
	  ,r.Regione
FROM Clienti c
INNER JOIN PuntiVenditaClienti pv
ON c.CodCliente = pv.CodCliente
INNER JOIN Regioni r
ON pv.CodRegione = r.CodRegione
GROUP BY c.RagioneSociale, r.Regione
HAVING r.Regione = 'Abruzzo'

--7.Visualizzare quanti anni ogni dipendete ha maturato dall'assunzione
SELECT  CONCAT (Nome,' ',Cognome)                Impiegato
	  ,DataAssunzione
	  ,DATEDIFF (YEAR, DataAssunzione,GETDATE()) AnniMaturati
FROM Impiegati

--8.Vista che espone l'elenco dei punti vendita dei clienti collolati in regioni differenti da quelle dei distretti

CREATE VIEW sm_v_PVFuoriDistretto AS
		SELECT pv.NomePuntoVendita
	  , pv.SedePuntoVendita
	  ,r.Regione
FROM Regioni r
RIGHT JOIN PuntiVenditaClienti pv
ON r.CodRegione = pv.CodRegione
WHERE Regione NOT IN ( SELECT Regione
                       FROM Distretti)

--9.Elenco dei Punti Vendita che rientrano, per le dimensioni nella Fascia Prezzi 2

SELECT DISTINCT pv.NomePuntoVendita
	  ,pv.SedePuntoVendita
	  ,fp.RangeDimPuntoVendita
FROM PuntiVenditaClienti pv
INNER JOIN Clienti c
ON pv.CodCliente = c.CodCliente
INNER JOIN AccordiPrestazione ap
ON c.CodCliente = ap.CodCliente
INNER JOIN Prestazioni p
ON ap.CodAccordo = p.CodAccordo
INNER JOIN Servizi s
ON p.CodServizio = s.CodServizio
INNER JOIN FascePrezzi fp
ON s.CodServizio = fp.CodServizio
WHERE fp.NFascia = 'F-2'

--10.Elenco dei clienti che hanno stipulato pi� di 5 accordi di prestazione

SELECT ap.CodCliente
	   ,c.RagioneSociale
	   ,COUNT (ap.CodAccordo)  AccordiStipulati
FROM AccordiPrestazione ap
INNER JOIN Clienti c
ON ap.CodCliente = c.CodCliente
GROUP BY ap.CodCliente, c.RagioneSociale
HAVING COUNT (ap.CodAccordo) >5